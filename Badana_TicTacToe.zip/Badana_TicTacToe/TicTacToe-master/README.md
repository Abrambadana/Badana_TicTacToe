Abram E. Badana

Instructions
Step 1: download the zipped folder(Badana_TicTacToe).
Step 2: extract the zipped folder(Badana_TicTacToe).
Step 3: open visual studio 2022.
Step 4: select open a local folder and browse to the file path of extracted zip file.
Step 5: browse then click to Badana_TicTacToe.sln
Step 6: run the program (ctrl + F5).
Step 7:Enjoy the game.

Note: -When Switching from SinglePlayer to Multiplayer and vice versa.. you need to rerun the program to avoid complications.
      -When choosing multiplayer mode, copy the url then open another window/tab then paste the url and click multiplayer.
